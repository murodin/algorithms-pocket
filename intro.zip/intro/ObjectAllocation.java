package chapter1.intro;

import java.util.function.Consumer;

class Message {

    private int id;
    private String description;

    private Message() {}

    public Message id(int id) {
        this.id = id;
        System.out.printf("id: %s%n", this.id);
        return this;
    }

    // Creation operation should end in description method 🥇
    public void description(String description) {
        this.description = description;
        System.out.printf("description: %s%n", this.description);
    }

    public static void sendMessage(Consumer<Message> messageConsumer) {
        Message message = new Message();
        messageConsumer.accept(message);
        send(message);
    }

    public static String mapToCustomString(Consumer<Message> messageConsumer) {
        Message message = new Message();
        messageConsumer.accept(message);
        return String.format("id: %s - description: %s", message.id, message.description);
    }

    private static void send(Message message) {
        System.out.printf("Message: %s sending %n", message);
    }
}

public class ObjectAllocation {

    public static void main(String[] args) {
        Message.sendMessage(message -> message.id(1).description("Message should be send"));
        Message.sendMessage(message -> message.id(10));

        String messageOut = Message.mapToCustomString(message -> message.id(111).description("Message"));
        System.out.println("Message Out: " + messageOut);
    }
}
