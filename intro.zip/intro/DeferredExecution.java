package chapter1.intro;

import java.util.function.Supplier;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DeferredExecution {

    private static final Logger logger = Logger.getLogger(String.valueOf(DeferredExecution.class));

    enum LEVEL {
        OFF(0), FINE(1), FINER(2), DEBUG(3), ERROR(4);

        private final int value;

        LEVEL(int value) {
            this.value = value;
        }

        public int intValue() {
            return this.value;
        }
    }

    public static void main(String[] args) {
//        withLogger();
        customLogger();
    }

    private static void customLogger() {
        // Better, but still problem to call generateDiagnostic method even if Level is NOT FINER
        log(LEVEL.DEBUG, String.format("Problem: %s", generateDiagnostic("Not Supplier")));

        // Best, Deferred Execution, pass Supplier to log method
        log(LEVEL.DEBUG, () -> String.format("No Problem: %s", generateDiagnostic("Supplier")));
    }

    private static void withLogger() {
        // Better, but still problem to call generateDiagnostic method even if Level is NOT FINER
        logger.log(Level.FINER, String.format("Problem: %s", generateDiagnostic("Not Supplier")));

        // Best, Deferred Execution, pass Supplier to log method
        logger.log(Level.FINER, () -> String.format("No Problem: %s", generateDiagnostic("Supplier")));
    }

    private static void log(LEVEL level, Supplier<String> msgSupplier) {
        if (isLoggable(level)) {
            return;
        }
        System.out.println("Supplier - Logged: " + msgSupplier.get());
    }

    public static void log(LEVEL level, String msg) {
        if (isLoggable(level)) {
            return;
        }
        System.out.println("String - Logged: " + msg);
    }

    private static boolean isLoggable(LEVEL level) {
        int levelValue =  LEVEL.ERROR.intValue(); // MAGIC stays here!!! - (!!!)Change Log LEVEL FINE to DEBUG 🧐
        return level.intValue() < levelValue || level.intValue() == levelValue;
    }

    private static String generateDiagnostic(String msg) {
        System.out.printf("generateDiagnostic method called - msg: %s%n", msg);
        //logger.finer(String.format("msg: %s - generateDiagnostic method called!!!", msg));
        return "Log-Test-Return-Value";
    }
}
