package chapter1.intro;

import java.util.function.Function;

@FunctionalInterface
interface CurriedFunction<T, U, R> {
    Function<T, R> apply(U u);
}

public class Currying {

    public static void main(String[] args) {
        CurriedFunction<Integer, Integer, Integer> sumFunction = a -> b -> a + b;
        System.out.printf("Curried Function: %s%n", sumFunction.apply(10).apply(30));
    }
}
