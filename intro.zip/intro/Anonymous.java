package chapter1.intro;

public class Anonymous {

    public static void main(String[] args) {

        Runnable runnableAnonymous= new Runnable() {
            @Override
            public void run() {
                System.out.println("Test");
            }
        };

        Runnable runnableLambda = () -> System.out.println("Test");

        // 🆗
        doSomething(new Task() {
            public void execute() {
                System.out.println("Danger danger!!");
            }
        });

        // ⏸ Compile Error which doSomething, for Runnable or Task parameter
        //doSomething(() -> System.out.println("Danger danger!!!"));
        doSomething((Task)() -> System.out.println("Danger danger!!!!"));
    }

    interface Task {
        public void execute();
    }

    public static void doSomething(Runnable r){ r.run(); }
    public static void doSomething(Task t){ t.execute(); }
}
